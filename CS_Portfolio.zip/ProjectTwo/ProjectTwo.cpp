#include <iostream>     // For input/output
#include <fstream>      // For file handling
#include <sstream>      // For string stream parsing
#include <vector>       // For using vector to hold prerequisites
#include <string>       // For using string
#include <algorithm>    // For transform function

using namespace std;

// Structure to represent a course
struct Course {
    string courseId;                 // Course ID (e.g., CSCI100)
    string title;                    // Course title
    vector<string> prerequisites;    // List of prerequisite course IDs
};

// Node structure for Binary Search Tree
struct Node {
    Course course;   // Course object held in this node
    Node* left;      // Pointer to left child
    Node* right;     // Pointer to right child

    // Constructor
    Node(Course c) {
        course = c;
        left = NULL;
        right = NULL;
    }
};

// Binary Search Tree class
class BST {
private:
    Node* root;  // Root node of BST

    // Helper function to add a node
    void addNode(Node*& node, Course course) {
        if (node == NULL) {
            node = new Node(course);
        } else if (course.courseId < node->course.courseId) {
            addNode(node->left, course);
        } else {
            addNode(node->right, course);
        }
    }

    // Helper function for in-order traversal
    void inOrder(Node* node) {
        if (node != NULL) {
            inOrder(node->left);
            cout << node->course.courseId << ", " << node->course.title << endl;
            inOrder(node->right);
        }
    }

    // Helper function to search for a course by ID
    Course* search(Node* node, string courseId) {
        if (node == NULL) return NULL;
        if (node->course.courseId == courseId) return &node->course;
        if (courseId < node->course.courseId)
            return search(node->left, courseId);
        else
            return search(node->right, courseId);
    }

public:
    // Constructor
    BST() {
        root = NULL;
    }

    // Insert a course into BST
    void insert(Course course) {
        addNode(root, course);
    }

    // Print all courses in sorted order
    void printInOrder() {
        inOrder(root);
    }

    // Find a course by ID
    Course* find(string courseId) {
        return search(root, courseId);
    }
};

// Parse a course from a line of CSV input
Course parseCourse(string line) {
    stringstream ss(line);
    string courseId, title, token;
    getline(ss, courseId, ',');   // Read course ID
    getline(ss, title, ',');      // Read course title
    vector<string> prereqs;
    while (getline(ss, token, ',')) {   // Read prerequisites
        prereqs.push_back(token);
    }
    cout << "Parsed: " << courseId << ", " << title << endl;  // Debug output
    Course c;
    c.courseId = courseId;
    c.title = title;
    c.prerequisites = prereqs;
    return c;
}

// Load course data from a file into the BST
void loadCourses(string filename, BST& bst) {
    ifstream file;
    file.open(filename.c_str());
    if (!file.is_open()) {
        cerr << "Error: Cannot open file " << filename << endl;
        return;
    }
    string line;
    while (getline(file, line)) {
        cout << "Reading line: " << line << endl;  // Debug output
        Course course = parseCourse(line);
        bst.insert(course);
    }
    file.close();
    cout << "Courses loaded successfully.\n";
}

int main() {
    BST bst;                            // BST to store courses
    string filename = "courses.csv";   // Name of CSV file to load
    int choice = 0;                     // Menu choice
    bool dataLoaded = false;           // Tracks if data has been loaded

    while (true) {
        // Display menu
        cout << "\nMenu:" << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Print Course Info" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";

        // Validate input as an integer
        if (!(cin >> choice)) {
            cin.clear();                 // Clear error state
            cin.ignore(10000, '\n');     // Discard invalid input
            cout << "Invalid choice. Please try again.\n";
            continue;
        }

        switch (choice) {
            case 1:
                // Load course data from file
                loadCourses(filename, bst);
                dataLoaded = true;
                break;

            case 2:
                // Load automatically if not already loaded
                if (!dataLoaded) {
                    cout << "Data not loaded yet. Loading now...\n";
                    loadCourses(filename, bst);
                    dataLoaded = true;
                }
                // Print sorted course list
                cout << "Course List:\n";
                bst.printInOrder();
                break;

            case 3: {
                // Load automatically if not already loaded
                if (!dataLoaded) {
                    cout << "Data not loaded yet. Loading now...\n";
                    loadCourses(filename, bst);
                    dataLoaded = true;
                }
                // Prompt for course ID to display info
                string courseId;
                cout << "Enter course ID: ";
                cin >> courseId;
                transform(courseId.begin(), courseId.end(), courseId.begin(), ::toupper);
                Course* course = bst.find(courseId);
                if (course != NULL) {
                    cout << course->courseId << ", " << course->title << endl;
                    if (course->prerequisites.size() > 0) {
                        cout << "Prerequisites: ";
                        for (size_t i = 0; i < course->prerequisites.size(); ++i) {
                            cout << course->prerequisites[i] << " ";
                        }
                        cout << endl;
                    } else {
                        cout << "No prerequisites.\n";
                    }
                } else {
                    cout << "Course not found.\n";
                }
                break;
            }

            case 9:
                // Exit the program
                cout << "Goodbye!\n";
                return 0;

            default:
                cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
