# Portfolio Submission for Data Structures and Algorithms

## Reflection

### What was the problem you were solving in the projects for this course?
In these projects, I addressed the challenge of organizing and accessing university course data efficiently. Project One focused on analyzing the runtime and memory usage of different data structures—specifically vectors, hash tables, and binary search trees (BSTs)—to determine the most effective structure for managing and querying course information. Project Two expanded on this by implementing a working C++ program using a binary search tree to load course data from a file and sort it in alphanumeric order.

### How did you approach the problem? Why are data structures important to understand?
My approach involved both analytical and hands-on programming work. First, I evaluated how each data structure performed in terms of time complexity (e.g., O(n), O(log n), O(1)) and memory usage. This theoretical understanding helped guide the selection of the BST in Project Two for its efficiency in sorted insertions and lookups.

Understanding data structures is critical because they dictate how efficiently a program can store, access, and manipulate data. Choosing the right data structure improves performance, reduces bugs, and simplifies code logic.

### How did you overcome any roadblocks you encountered while going through the activities or project?
One of the key challenges I faced was managing data input from external files and ensuring it was parsed and stored correctly. I resolved these issues through step-by-step debugging, console logging for visibility, and verifying data formats ahead of insertion. Another challenge was understanding how tree traversal works recursively, which I overcame by carefully mapping out traversal logic and testing incrementally.

### How has your work on this project expanded your approach to designing software and developing programs?
This project reinforced the importance of choosing the right data structure based on requirements. It also helped me think more modularly—breaking down tasks like file parsing, data loading, BST insertion, and traversal into discrete, reusable functions. These skills are directly applicable to larger software design principles such as encapsulation and single responsibility.

### How has your work on this project evolved the way you write programs that are maintainable, readable, and adaptable?
I learned to prioritize clean, modular code and include helpful comments to aid future maintenance. Additionally, I now structure code with future adaptability in mind—for example, by creating helper functions and avoiding hardcoding. This practice will allow future enhancements (like adding GUI support or expanding data fields) with minimal restructuring.
